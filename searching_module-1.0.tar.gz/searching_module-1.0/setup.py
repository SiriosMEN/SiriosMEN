from setuptools import setup
setup(
    name = 'searching_module',
    version='1.0',
    description='Searching for letters and vowels',
    author = 'Siriosmen',
    author_email='test@gmail.com',
    url='site.com',
    py_modules=['searching_module'],
    )
